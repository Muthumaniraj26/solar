package com.yourdomain.solarforecast;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
